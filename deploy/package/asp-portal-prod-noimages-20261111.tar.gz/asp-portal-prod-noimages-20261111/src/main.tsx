import { StrictMode } from 'react'
import './i18n'
import { createRoot } from 'react-dom/client'
import './fonts'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
